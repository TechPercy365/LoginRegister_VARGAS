﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoginRegistration_VARGAS.Model
{
    public class User
    {
        public User()
        {            
        }

        public string username { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string email { get; set; }
        public string contactNum { get; set; }
        public string userPassword { get; set; }
        
    }
}
