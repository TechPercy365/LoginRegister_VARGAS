﻿using LoginRegistration_VARGAS.Forms;
using LoginRegistration_VARGAS.Repository;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoginRegistration_VARGAS
{
    public partial class Form_Login : Form
    {
        UserRepository userRepo;
        public Form_Login()
        {
            InitializeComponent();
            userRepo = new UserRepository();
        }

        private void click_Register_Click(object sender, EventArgs e)
        {
            new Register().Show();
            this.Hide();
        }

        private void btn_Login_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(txt_userID.Text))
            {
                MessageBox.Show("ERROR: Empty Field. Please Fill in");
                return;
            }
            if (String.IsNullOrEmpty(txt_userPass.Text))
            {
                MessageBox.Show("ERROR: Empty Field. Please Fill in");
                return;
            }

            var userLogged = userRepo.GetUserByUsername(txt_userID.Text);

            if (userLogged != null)
            {
                if (userLogged.userPassword.Equals(txt_userPass.Text))
                {
                    // Assigned to a singleton
                    UserLogged.GetInstance().User = userLogged;

                    new Users_DashBoard().Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Incorrect Password");
                }
            }
            else
            {
                MessageBox.Show("Username not found");
            }

        }
    }
}
