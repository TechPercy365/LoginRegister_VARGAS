﻿using LoginRegistration_VARGAS.Model;
using LoginRegistration_VARGAS.Repository;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace LoginRegistration_VARGAS
{
    public partial class Register : Form
    {
        UserRepository userRepo;
        public string username = String.Empty;
        sampleUserDBEntities3 db;
        public Register()
        {
            InitializeComponent();
            db = new sampleUserDBEntities3();
        }

        private void backRegister_Click(object sender, EventArgs e)
        {
            new Form_Login().Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(txt_UName.Text))
            {
                MessageBox.Show("Error: Invalid Username");
                return;
            }
            if (String.IsNullOrEmpty(txt_CreatePass.Text))
            {
                txt_CreatePass.Clear();
                MessageBox.Show("Error: Empty Field");
                return;
            }
            if (String.IsNullOrEmpty(txt_ConfirmPass.Text))
            {
                txt_ConfirmPass.Clear();
                MessageBox.Show("Error: Empty Field");
                return;
            }

            if (!txt_CreatePass.Text.Equals(txt_ConfirmPass.Text))
            {
                txt_CreatePass.Clear();
                MessageBox.Show("Error: Password Not Match");
                return;
            }
          
            
            User nUserAccount = new User();
            nUserAccount.username = txt_UName.Text;
            nUserAccount.userPassword = txt_ConfirmPass.Text;
            nUserAccount.firstName = txt_Fname.Text;
            nUserAccount.lastName = txt_Lname.Text;


            username = txt_UName.Text;

            db.User.Add(nUserAccount);
            db.SaveChanges();

            txt_CreatePass.Clear();
            txt_ConfirmPass.Clear();
            txt_UName.Clear();
            MessageBox.Show("Registered!");
        }
    }
}
