﻿using LoginRegistration_VARGAS.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoginRegistration_VARGAS.Repository
{
    public class UserRepository
    {
        private sampleUserDBEntities3 db;
        public UserRepository() { db = new sampleUserDBEntities3(); }

        public ErrorCode NewUser(User aUserAccount, ref String outMessage)
        {
            ErrorCode retValue = ErrorCode.Error;
            try
            {
                db.User.Add(aUserAccount);
                db.SaveChanges();

                outMessage = "Inserted";
                retValue = ErrorCode.Success;
            }
            catch (Exception ex)
            {
                outMessage = ex.Message;
                MessageBox.Show(ex.Message);
            }
            return retValue;
        }

        public User GetUserByUsername(String username)
        {
            // re-initialize db object because sometimes data in the list not updated
            using (db = new sampleUserDBEntities3())
            {
                // SELECT TOP 1 * FROM USERACCOUNT WHERE userName == username
                return db.User.Where(s => s.username == username).FirstOrDefault();
            }
        }

    }
}
