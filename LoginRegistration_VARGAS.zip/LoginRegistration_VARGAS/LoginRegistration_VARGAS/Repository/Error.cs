﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoginRegistration_VARGAS.Repository
{
    public enum ErrorCode
    {
        Success = 0,
        Error = 1
    }
    public class Error
    {

    }
}
