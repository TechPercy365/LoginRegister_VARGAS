CREATE DATABASE sampleUserDB

USE sampleUserDB

CREATE TABLE [User] (
	username varchar(50) PRIMARY KEY,
	firstName varchar(30),
	lastName varchar(30),
	email varchar(50),
	contactNum varchar(50),
	userPassword varchar(20)	
)

DROP TABLE [User]




